clc;
clear all;

% Input parameters.
max_B = 15000; % maximum magnetic field that you want to display in the figure. 
min_B = -15000; % minimum magnetic field that you want to display in the figure. 
delta_B = 100; % the minimum increment of magnetic field when measuring. 


% Read all excel files in the same folder.
Files = dir(strcat('*.xlsx'));
sp = [];
ep = [];
Files_number = length(Files);
disp(Files_number);
B = [];

for k = 1:Files_number
    disp(strcat(Files(k).name));
    RB_data = xlsread(strcat(Files(k).name));
    B = RB_data(:,2);
    B_length=size(B);
  
% Find start position and end position of measured magnetic field in sequential order and reverse order at the same temperature.
    for i=2:(B_length-1)
        if (abs(B(i)-B(i-1))<delta_B && abs(B(i+1)-B(i))>delta_B)
            fprintf('start');
            disp(i);
            sp =[sp i];
        end
        if (abs(B(i+1)-B(i))<delta_B && abs(B(i)-B(i-1))>delta_B)
            fprintf('stop');
            disp(i);
            ep = [ep i];
        end
    end
    
    if size(sp) < 2
        sp = [1 sp];
    end
    if size(ep) < 2
        ep = [ep size(B)];
    end

    length = min((ep(1)-sp(1)+1),ep(2)-sp(2)+1);
    disp(length);
    disp(sp);
    new_ep(1) = sp(1)+length-1;
    new_ep(2) = sp(2)+length-1;
    fprintf('new end');
    disp(new_ep);
   
    length = floor(B_length(1)/2);
    sp = [1,length+1];
    new_ep = [length, length*2];
    disp(sp);
    disp(new_ep);
    
    % Read the values of Rxx and Rxy measured in sequential magnetic field order. 
    B1 = RB_data(sp(1):new_ep(1),2);
    reverse_B1 = flip(B1);
    reverseRxy1 = RB_data(sp(1):new_ep(1),3);
    Rxy1 = flip(reverseRxy1);
    reverseRxx1 = RB_data(sp(1):new_ep(1),4);
    Rxx1 = flip(reverseRxx1);

    % Read the values of Rxx and Rxy measured in reverse magnetic field order.
    B2 = RB_data(sp(2):new_ep(2),2);
    Rxy2 = RB_data(sp(2):new_ep(2),3);
    reverseRxy2 = flip(Rxy2);
    Rxx2 = RB_data(sp(2):new_ep(2),4);
    reverseRxx2 = flip(Rxx2);

    % Symmetrization
    for j = 1 : length
        real_Rxy2(j) = (Rxy2(j) - reverseRxy1(j))/2;
        real_Rxy1(j) = (Rxy1(j) - reverseRxy2(j))/2;
        real_Rxx2(j) = (Rxx2(j) + reverseRxx1(j))/2;
        real_Rxx1(j) = (Rxx1(j) + reverseRxx2(j))/2;
    end
    
    fit_B2 = B2(1:1:20);
    fit_Rxy2 = real_Rxy2(1:1:20);
    s = polyfit(fit_B2,fit_Rxy2,1);
    slope = s(1);
    
    for l = 1 : length
        final_Rxy2(l) = real_Rxy2(l) - slope * B2(l);
        final_Rxy1(l) = real_Rxy1(l) - slope * reverse_B1(l);
    end
   
%     % Save the rearranged data in different txt files. 
%     real_B = [reverse_B1' flip(B2)'];
%     real_Rxy = [final_Rxy1 flip(final_Rxy2)]; 
%     total_RB = [real_B',real_Rxy'];
% 
%     T = RB_data(:,1);
%     Tm = round(T(1));
%     write = sprintf('%d.txt',Tm);
%     filename = [write];
%     dlmwrite(filename,total_RB,'delimiter','\t'); 

% 
  % Plot figures
    name = extractBefore(Files(k).name,'.xlsx');
    figure('NumberTitle','off','Name',name);
    f(k) = plot(reverse_B1,final_Rxy1,'Linewidth',2.5);
    xlabel('B (Oe)','Fontsize',20)
    ylabel('Ryx (Ohm)','Fontsize',20)
    box on
    set(gca,'Fontsize',20)
    axis padded
    axis([min_B max_B,-inf,inf])    % Change x-axis range. 
    hold on
    f(k) = plot(B2,final_Rxy2,'Linewidth',2.5);
    xlabel('B (Oe)','Fontsize',20)
    ylabel('Ryx (Ohm)','Fontsize',20)
    box on
    set(gca,'Fontsize',20)
    axis padded
    axis([min_B max_B,-inf,inf])   % Change x-axis range. 
    grid on
    xline(0)
    yline(0)
    txt = name;
    t = text(max_B/2,max(final_Rxy2)/2,txt) % Add temperature in every figure. 
    t.FontSize = 20;
    hold off
    print(name,'-dtiff')  % Save figures as 'tiff' format.
    

    sp = [];
    ep = [];
    real_Rxy2 = [];
    real_Rxy1 = [];
    real_Rxx2 = [];
    real_Rxx1 = [];
    final_Rxy1 = [];
    final_Rxy2 = [];

end



clc;
clear all;

% Input parameters
delta_T = 0.5; % half of the minimum increment of measured temperature.


% PLOT R-T FIGURE.
RTdata = xlsread('BCT21_100uA.xlsx',1,'A2:D214');% <====================== edit edit edit edit edit edit
% read R-T data in excel (which should be in the same path with the matlab program).
% A1:C2959 means the range of data where Monment changes as temperature.

T = RTdata(:,1); % Temperature is in the 1st column of the chosen data;
R = RTdata(:,3); % R is in the 3rd column of the chosen data;

% Plot R-T figure.
figure
plot(T,R,'r-','Linewidth',2.5)
xlabel('T (K)','Fontsize',20)
ylabel('R (Ohm)','Fontsize',20)
box on
grid on
set(gca,'Fontsize',20)


%% Divide the residual data into several parts according to the measured temperature.
% ============================================================================================================

Residual_Data = xlsread('BCT21_100uA.xlsx',1,'A215:F1281'); % <====================== edit edit edit edit
Temperature = Residual_Data(:,1);
B = Residual_Data(:,2);
Rxx = Residual_Data(:,3);
Rxy = Residual_Data(:,4);
a = 1;
Tm = round(Temperature(1));

for i = 1:(length(Temperature)-1)
    if (Temperature(i+1) - Temperature(i)) > 0.5 % Find the position of changing temperature. 
            fprintf('i');
            disp(Tm);
            New_T = Temperature(a:i);
            New_B = B(a:i);
            New_Rxx = Rxx(a:i);
            New_Rxy = Rxy(a:i);
            filename = sprintf('%dK.xlsx',Tm);
            range = sprintf('A1:D%d',length(New_B));
            xlswrite(filename,[New_T New_B New_Rxy New_Rxx],range);
            a=i+1;
            Tm = round(Temperature(i+1));
    end
end
New_T = Temperature(a:length(Temperature));
New_B = B(a:length(Temperature));
New_Rxx = Rxx(a:length(Temperature));
New_Rxy = Rxy(a:length(Temperature));
Tm = round(Temperature(a));
filename = sprintf('%dK.xlsx',Tm);
range = sprintf('A1:D%d',length(New_B));
xlswrite(filename,[New_T New_B New_Rxy New_Rxx],range);







